import 'package:photo_manager/photo_manager.dart';

class PermissionProviderServices {
  Future<bool> requestPermission() async {
    var permission = await PhotoManager.requestPermissionExtend();
    if (permission.isAuth == true) {
      return true;
    } else {
      PhotoManager.openSetting();
      return false;
    }
  }
}
