// import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';


import '../wigets/app_bar_widget.dart';
import '../wigets/dropdown_view.dart';
import '../wigets/hero_text.dart';

// import '../services/media_provider.dart';
// import '../services/permission_provider.dart';
// import 'dropdown_view.dart';

class HomeScreen extends StatefulWidget {
  // static var imageAssetList;

  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // late String imageAssetPath;

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
  }

  @override
  Widget build(BuildContext context) {
    var screenHeight = MediaQuery.of(context).size.height;
    var screenWidth = MediaQuery.of(context).size.width;

    return SafeArea(
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xff206946), Color(0xff071414), Color(0xff040807)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: Padding(
            padding: const EdgeInsets.all(15),
            child: Column(
              children: [
                const AppBarWidget(),
                HeroText(
                  firstLine: "Select Images",
                  secondLine: "to Continue",
                  thirdLine: "Upto 10 images",
                ),
                Expanded(child: DropDownView()),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
