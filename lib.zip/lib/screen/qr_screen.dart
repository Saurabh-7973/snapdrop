import 'package:flutter/material.dart';
import 'package:photo_manager/photo_manager.dart';

import '../wigets/app_bar_widget.dart';
import '../wigets/figma_display_helper.dart';
import '../wigets/hero_text.dart';
import '../wigets/qr_scanner.dart';


class QRScreen extends StatefulWidget {

    List<AssetEntity> selectedAssetList;
    QRScreen({required this.selectedAssetList});

  @override
  State<QRScreen> createState() => _QRScreenState();
}

class _QRScreenState extends State<QRScreen> {

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xff206946), Color(0xff071414), Color(0xff040807)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Padding(
          padding: const EdgeInsets.all(15),
          child: Column(
            children: [
              const AppBarWidget(),
              HeroText(
                  firstLine: "Select a Plugin",
                  secondLine: "to Continue",
                  thirdLine: ""),
              const FigmaDisplayHelper(),
              const SizedBox(height: 10,),
              QRScanner(selectedAssetList: widget.selectedAssetList),
              const SizedBox(height: 10,),
              // ConnectionButton(),
            ],
          ),
        ),
      ),
    ));
  }
}
