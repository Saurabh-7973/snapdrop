import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:snapdrop/wigets/app_bar_widget.dart';

import '../services/socket_service.dart';
import '../wigets/connect.dart';
import '../wigets/room_displayer.dart';
import '../wigets/selected_images.dart';

class SendFile extends StatelessWidget {

  String roomId;
  List<AssetEntity> selectedAssetList;
  SocketService? socketService;
  SendFile({super.key , required this.selectedAssetList ,  required this.roomId , required this.socketService});


  @override
  Widget build(BuildContext context) {

      var screenHeight = MediaQuery.of(context).size.height;
    var screenWidth = MediaQuery.of(context).size.width;

    return SafeArea(
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xff206946), Color(0xff071414), Color(0xff040807)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child:  Scaffold(
          backgroundColor: Colors.transparent,
          body: Padding(
            padding:  const EdgeInsets.all(15),
            child: Column(
              children: [
                const AppBarWidget(),
                Container(
                  color: Colors.transparent,
                  height: screenHeight / 4.3,
                  width: screenWidth,
                  child: Lottie.asset('assets/animations/snapdrop_send_files.json',fit: BoxFit.cover)),
                RoomDisplayer(roomId: roomId),
                Container(
                  height: screenHeight / 2.5,
                  color: Colors.transparent,
                  child: SelectedImagesViewer(selectedAssetList:selectedAssetList,)),
                  const SizedBox(height: 10,),
                  SendButton(socketService: socketService, selectedAssetList: selectedAssetList,),
              ],
            ),
          ),
        )
        )
    );
  }
}