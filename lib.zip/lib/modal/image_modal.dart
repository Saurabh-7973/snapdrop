import 'dart:developer';
import 'dart:io';

import 'package:photo_manager/photo_manager.dart';

import 'dart:async';
import 'package:flutter/services.dart' show ByteData, Uint8List, rootBundle;


class ImageModal{
  String? name;
  String? type;
  Uint8List? bufferImage;
  String? senderSocketId;

  List<ImageModal>? listOfImageModal;

  void addItemsToImageModal(AssetEntity assetEntity){
    log('');
    // File file;
    // assetEntity.file.then((value) {
    //   file = File(value);
    // });    
    //final file = File(assetEntity.file);
    
    
  
  }





}