import 'dart:developer';
import 'package:photo_manager/photo_manager.dart';

// import 'permission_provider.dart';

class MediaProviderServices {
  Future<List<AssetPathEntity>> loadAlbums(bool hasAll) async {
    List<AssetPathEntity> albumList = [];
    albumList = await PhotoManager.getAssetPathList(
        type: RequestType.image, hasAll: hasAll);
    //log("Data: $albumList");
    return albumList;
  }

  // Future<List<AssetEntity>> loadAsset(AssetPathEntity selectedAlbum) async {
  //   List<AssetEntity> assetList = [];
  //   int assetCount ;
  //   getAssetCount(selectedAlbum).then((count) async {
  //     assetCount = count;
  //     log("Asset Count: $assetCount");
  //     // selectedAlbum.getAssetListRange(start: 0, end: count).then((listOfAsset) {
  //     //   assetList = listOfAsset;
  //     //   return assetList;
  //     // } );
  //     assetList = await selectedAlbum.getAssetListRange(start: 0, end: assetCount);
  //     log("$assetList");
  //     return assetList;
  //   } );
  //   // selectedAlbum.assetCountAsync.then((count) async {
  //   //   assetList = await selectedAlbum.getAssetListRange(start: 0, end: count);
  //   // } );
  //   return [];
  // }

  Future loadAsset(AssetPathEntity selectedAlbum) async {
    List<AssetEntity> assetList = await selectedAlbum.getAssetListRange(
        start: 0,
        end:
            // ignore: deprecated_member_use
            selectedAlbum.assetCount);
    return assetList;
  }

  Future<int> getAssetCount(AssetPathEntity selectedAlbum) async {
    int assetCount;
    assetCount = await selectedAlbum.assetCountAsync;
    return assetCount;
  }
}
