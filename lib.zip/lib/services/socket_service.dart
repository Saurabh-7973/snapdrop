import 'dart:developer';
import 'dart:io';
import 'dart:typed_data';

import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:socket_io_client/socket_io_client.dart';

class SocketService{

  String _url;
  String? _userId;
  String? _roomId;
  SocketService({required String url}) : _url = url;
  IO.Socket? socket;

  void connectToSocketServer(){
    _socketConnection();
    _onConnectChecker();
    _testMessage();
    _onConnectErrorChecker();
    _fetchUserId();
    _joinFigmaRoom();
  }

  void _socketConnection(){
    socket = IO.io('https://getsnapdrop.in/',
    OptionBuilder()
        .setTransports(['websocket']) 
        .setTimeout(10000)
        .build());

    socket!.connect();
  }

  void _testMessage(){
    socket!.emit('test','sad');
  }

  void _onConnectChecker(){
    socket!.onConnect((data) {
      log('Socket Connected Successfull! $data');
    });
  }

  void _onConnectErrorChecker(){
    socket!.on('connect_error', (error) {
      log('Connection Error: $error');
    });
  }

  void _joinFigmaRoom(){
    //To get the room id
    log(_url);
    _roomId = _url.toString().split('=')[1];
    log("Room Id: $_roomId");

    socket!.emit("join_figma_room", {
      'my_id': _userId,
      'room': _roomId,
    });
  }


  void _fetchUserId(){
    socket!.on('your_id', (data) {
      log('Your ID: ${data['id']}');
      _userId = data['id'];
    });
  }

  void sendImages(Uint8List? file){
    //Currently buffer is empty

    socket!.emit("image", {
          'room': _roomId,
          'files':  [{
              'name': 'test',
              'type': 'jpg',
              'file': file,
              'sender': _userId,
                }],
          });
  }

  void transfer(){
    socket!.on('image_received_to_figma', (data) {
      
    });
  }

  Future<String?> getUserId() async {
    return _userId;
  }

  Future<Uint8List?> fileToBuffer(String filePath) async {
  // Create a File object by providing the file path.
  File file = File(filePath);

  try {
    // Read the file contents as bytes.
    Uint8List buffer = await file.readAsBytes();
    return buffer;
  } catch (e) {
    // Handle any potential errors, such as file not found.
    print('Error reading file: $e');
    return null;
  }
}



}