import 'package:flutter/material.dart';
import 'package:snapdrop/constant/theme_contants.dart';

class RoomDisplayer extends StatelessWidget {

  String roomId;

   RoomDisplayer({super.key , required this.roomId});

  @override
  Widget build(BuildContext context) {

    ThemeConstant themeConstant = ThemeConstant();
    
    return Column(
      children: [
        const SizedBox(height: 10,),
        const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('SEND FILES TO SERVER',style: TextStyle(fontSize: 16 , color: Colors.grey),)
          ],
        ),
        const SizedBox(height: 10,),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(roomId, style: const TextStyle(color: Colors.white , fontSize: 28),)
          ],
        ),
        const SizedBox(height: 10,),
      ],
    );
  }
}