import 'dart:developer';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:snapdrop/constant/theme_contants.dart';
import 'package:snapdrop/screen/qr_screen.dart';

import '../services/file_image.dart';
import '../services/media_provider.dart';
import '../services/permission_provider.dart';

class DropDownView extends StatefulWidget {
  DropDownView({super.key});

  final PermissionProviderServices _permissionProviderServices =
      PermissionProviderServices();
  final MediaProviderServices _mediaProviderServices = MediaProviderServices();
  final ThemeConstant _themeConstant = ThemeConstant();

  @override
  State<DropDownView> createState() => _DropDownViewState();
}

class _DropDownViewState extends State<DropDownView> {
  List<AssetPathEntity> albumList = [];
  List<AssetEntity> assetList = [];
  AssetPathEntity? selectedAlbum;
  List<AssetEntity> selectedAssetList = [];
  bool hasAll = false;
  // double totalSelectedImageSize = 0.0;
  // String imageSize = '0.0';
  // ValueNotifier<double> totalSelectedImageSize = ValueNotifier<double>(0.0);

  @override
  void initState() {
    initialMethod(hasAll);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final themeConstant = ThemeConstant();
    var screenHeight = MediaQuery.of(context).size.height;
    var screenWidth = MediaQuery.of(context).size.width;

    return Column(
      children: [
        albumList.isEmpty == true
            ? const Center(
                child: CircularProgressIndicator(
                  color: Colors.white,
                ),
              )
            : Row(
                children: [
                  DropdownButtonHideUnderline(
                    child: DropdownButton<AssetPathEntity>(
                        dropdownColor: const Color(0xff071414),
                        value: selectedAlbum,
                        icon: const Icon(
                          Icons.keyboard_arrow_down_rounded,
                          color: Colors.white,
                          size: 28,
                        ),
                        items: albumList
                            .map<DropdownMenuItem<AssetPathEntity>>((album) {
                          return DropdownMenuItem<AssetPathEntity>(
                            value: album,
                            child: Text(
                              "${album.name} (${album.assetCount})",
                              style: widget._themeConstant.smallTextSizeLight,
                            ),
                          );
                        }).toList(),
                        onChanged: (AssetPathEntity? album) {
                          setState(() {
                            selectedAlbum = album;
                          });

                          widget._mediaProviderServices
                              .loadAsset(selectedAlbum!)
                              .then((value) {
                            setState(() {
                              assetList = value;
                            });
                          });
                        }),
                  ),
                  const Spacer(),
                  TextButton(
                      onPressed: () {
                        initialMethod(true);
                      },
                      child: const Text(
                        "View All",
                        style: TextStyle(color: Color(0xFF39C679)),
                      ))
                ],
              ),
        Expanded(
          child: Stack(children: [
            GridView.builder(
                itemCount: assetList.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 6,
                    crossAxisSpacing: 6,
                    childAspectRatio: (2 / 3)),
                itemBuilder: (context, index) {
                  //log("Index : $index");
                  return GestureDetector(
                    onTap: () {
                      if (selectedAssetList.contains(assetList[index])) {
                        setState(() {
                          selectedAssetList.remove(assetList[index]);
                        });
                      } else {
                        setState(() {
                          selectedAssetList.add(assetList[index]);
                        });
                      }
                    },
                    child: Stack(children: [
                      Positioned.fill(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(5),
                          child: AssetEntityImage(
                            assetList[index],
                            thumbnailSize: const ThumbnailSize.square(250),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      selectedAssetList.contains(assetList[index]) == true
                          ? const Align(
                              alignment: Alignment.topRight,
                              child: Padding(
                                padding: EdgeInsets.all(6.0),
                                child: Icon(
                                  Icons.check_circle_rounded,
                                  size: 30,
                                  color: Colors.white,
                                ),
                              ),
                            )
                          : Align(
                              alignment: Alignment.topRight,
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  height: 25,
                                  width: 25,
                                  decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Colors.black.withOpacity(0.4),
                                      border: Border.all(
                                          color: Colors.white, width: 2)),
                                  child: Container(),
                                ),
                              ),
                            ),
                      if (selectedAssetList.contains(assetList[index]) == true)
                        FutureBuilder(
                            future: FileImageServices()
                                .getImageSize(assetList[index]),
                            builder: (context, snapshot) {
                              if (snapshot.hasData) {
                                // totalSelectedImageSize = totalSelectedImageSize + double.parse(snapshot.data!);
                                // log("Future Add : $totalSelectedImageSize");
                                return Align(
                                  alignment: Alignment.bottomRight,
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Container(
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(15),
                                            color:
                                                Colors.grey.withOpacity(0.8)),
                                        child: Padding(
                                            padding: const EdgeInsets.all(4),
                                            child: Text(
                                              "${snapshot.data} MB",
                                              style: themeConstant
                                                  .smallTextSizeLight,
                                            ))),
                                  ),
                                );
                              }
                              return const Align(
                                alignment: Alignment.bottomRight,
                                child: Padding(
                                    padding: EdgeInsets.all(8.0),
                                    child: SizedBox(
                                        height: 10,
                                        width: 10,
                                        child: CircularProgressIndicator(
                                          color: Colors.white,
                                        ))),
                              );
                            })
                    ]),
                  );
                }),
            if (selectedAssetList.isNotEmpty)
              Align(
                alignment: Alignment.bottomRight,
                child: Container(
                  width: screenWidth / 3.6,
                  height: 40,
                  margin:
                      const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
                  child: ElevatedButton(
                    onPressed: () {
                      if (selectedAssetList.length >= 10) {
                        //log("Can only select upto 10 Images");
                        const snackbarLimit = SnackBar(
                            content: Text("Can Only select upto 10 Images !"));
                        ScaffoldMessenger.of(context)
                            .showSnackBar(snackbarLimit);
                      } else {
                        FileImageServices()
                            .getTotalImageSize(selectedAssetList)
                            .then((value) {
                          //log("Total Function : $value");
                          if (value < 5.0) {
                            //   var snackbarLimit = const SnackBar(
                            // content:  Text("Next Screen")
                            // );
                            // ScaffoldMessenger.of(context).showSnackBar(snackbarLimit);
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>  QRScreen(selectedAssetList: selectedAssetList,)));
                          } else {
                            var snackbarLimit = SnackBar(
                                content: Text(
                                    "File Size Limit Exceded (${value.toStringAsFixed(2)}) > 5 MB"));
                            ScaffoldMessenger.of(context)
                                .showSnackBar(snackbarLimit);
                          }
                        });
                      }
                    },
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30))),
                    child: Row(
                      children: [
                        Text(
                          "Connect",
                          style: themeConstant.smallTextSizeDark,
                        ),
                        const Spacer(),
                        const Icon(
                          Icons.arrow_forward_rounded,
                          color: Colors.black,
                        )
                      ],
                    ),
                  ),
                ),
              )
          ]),
        )
      ],
    );
  }

  initialMethod(bool hasAll) {
    widget._permissionProviderServices
        .requestPermission()
        .then((permission) async {
      //log("Permission : $value");
      if (permission == true) {
        //print("$permission");
        widget._mediaProviderServices.loadAlbums(hasAll).then((listOfAlbum) {
          //log("Albums : $listOfAlbum");
          if (listOfAlbum.isNotEmpty) {
            setState(() {
              albumList = listOfAlbum;
              //log("$albumList");
              selectedAlbum = listOfAlbum[0];
              //log("$selectedAlbum");
            });
            widget._mediaProviderServices
                .loadAsset(selectedAlbum!)
                .then((listOfAsset) {
              setState(() {
                assetList = listOfAsset;
              });
              //log("Befire condition $assetList");
            });
          }
        });
      }
    });
  }
}
