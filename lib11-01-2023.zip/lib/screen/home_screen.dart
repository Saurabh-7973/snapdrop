import 'dart:async';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';
import 'package:snapdrop/screen/intent_sharing_screen.dart';

import '../wigets/app_bar_widget.dart';
import '../wigets/dropdown_view.dart';
import '../wigets/hero_text.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // late String imageAssetPath;
  //StreamSubscription _intentDataStreamSubscription;

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);

    ReceiveSharingIntent.getInitialMedia()
        .then((List<SharedMediaFile> listOfMedia) {
      if (listOfMedia.isNotEmpty) {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => IntentSharingScreen(
                      listOfMedia: listOfMedia,
                    )));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    var screenHeight = MediaQuery.of(context).size.height;
    var screenWidth = MediaQuery.of(context).size.width;

    return SafeArea(
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xff206946), Color(0xff071414), Color(0xff040807)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: Padding(
            padding: const EdgeInsets.all(15),
            child: Column(
              children: [
                const AppBarWidget(),
                HeroText(
                  firstLine: "Select Images",
                  secondLine: "to Continue",
                  thirdLine: "Upto 10 images",
                ),
                Expanded(child: DropDownView()),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
