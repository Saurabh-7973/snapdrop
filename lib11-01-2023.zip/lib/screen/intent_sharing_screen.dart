import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';
import 'package:snapdrop/constant/theme_contants.dart';

import '../wigets/app_bar_widget.dart';
import '../wigets/hero_text.dart';
import 'send_file_screen.dart';

class IntentSharingScreen extends StatelessWidget {
  List<SharedMediaFile> listOfMedia;

  IntentSharingScreen({super.key, required this.listOfMedia});

  @override
  Widget build(BuildContext context) {
    ThemeConstant themeConstant = ThemeConstant();
    var screenHeight = MediaQuery.of(context).size.height;
    var screenWidth = MediaQuery.of(context).size.width;

    return SafeArea(
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xff206946), Color(0xff071414), Color(0xff040807)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: Padding(
            padding: const EdgeInsets.all(15),
            child: Column(
              children: [
                const AppBarWidget(),
                HeroText(
                  firstLine: "Shared Images",
                  secondLine: "from Other Apps",
                  thirdLine: "",
                ),
                Expanded(
                  child: Stack(
                    children: [
                      Expanded(
                        child: GridView.builder(
                            itemCount: listOfMedia.length,
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 3,
                                    crossAxisSpacing: 6,
                                    mainAxisSpacing: 6,
                                    childAspectRatio: (2 / 3)),
                            itemBuilder: (context, index) {
                              return Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(5),
                                ),
                                child: ClipRRect(
                                    borderRadius: BorderRadius.circular(5),
                                    child: Image.file(
                                      File(listOfMedia[index].path),
                                      fit: BoxFit.cover,
                                    )),
                              );
                            }),
                      ),
                      Align(
                        alignment: Alignment.bottomRight,
                        child: Container(
                          width: screenWidth / 3.6,
                          height: 40,
                          margin: const EdgeInsets.symmetric(
                              vertical: 8, horizontal: 8),
                          child: ElevatedButton(
                            onPressed: () {
                              //Navigator.push(context, MaterialPageRoute(builder: (context) => SendFile() ));
                            },
                            style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30))),
                            child: Row(
                              children: [
                                Text(
                                  "Connect",
                                  style: themeConstant.smallTextSizeDark,
                                ),
                                const Spacer(),
                                const Icon(
                                  Icons.arrow_forward_rounded,
                                  color: Colors.black,
                                )
                              ],
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
