import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';
import 'package:snapdrop/screen/home_screen.dart';

import 'screen/intent_sharing_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this); // Add the observer
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    // TODO: implement dispose
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // TODO: implement didChangeAppLifecycleState

    if (state == AppLifecycleState.paused) {
      log('App Paused Triggered');
    }
    if (state == AppLifecycleState.resumed) {
      log('App Resumed Triggered');
      ReceiveSharingIntent.getMediaStream().listen(
          (List<SharedMediaFile> listOfMedia) {
        if (listOfMedia.isNotEmpty) {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => IntentSharingScreen(
                        listOfMedia: listOfMedia,
                      )));
        }
      }, onError: (err) {
        debugPrint("$err");
      });
    }

    super.didChangeAppLifecycleState(state);
  }

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: HomeScreen(),
    );
  }
}
