import 'dart:developer';
import 'dart:io';

import 'package:photo_manager/photo_manager.dart';

import 'dart:async';
import 'package:flutter/services.dart' show ByteData, Uint8List, rootBundle;

class ImageModal {
  String? name;
  String? type;
  Uint8List? file;
  String? sender;

  ImageModal({required this.name, required this.type, this.file, this.sender});

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'type': type,
      'file': file,
      'sender': sender,
    };
  }
}
