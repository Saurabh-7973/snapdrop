import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:snapdrop/constant/theme_contants.dart';
import 'package:snapdrop/modal/image_modal.dart';

import '../services/socket_service.dart';

class SendButton extends StatelessWidget {
  SocketService? socketService;
  List<AssetEntity> selectedAssetList;
  List<ImageModal>? listOfImageModal = [];
  List<Map<String, dynamic>>? listOfMaps;

  SendButton(
      {super.key,
      required this.socketService,
      required this.selectedAssetList});

  @override
  Widget build(BuildContext context) {
    var screenHeight = MediaQuery.of(context).size.height;
    var screenWidth = MediaQuery.of(context).size.width;
    ThemeConstant themeConstant = ThemeConstant();

    return SizedBox(
      width: screenWidth / 1.3,
      height: 40,
      child: ElevatedButton(
          onPressed: () async {
            // selectedAssetList[0].file.then((value) {
            //   log('$value');
            // });
            // storingFilesInImageModal();
            // sendFilesToServer();
            for (int i = 0; i < selectedAssetList.length; i++) {
              selectedAssetList[i].originFile.then((value) {
                log("${value!.path}");
                String imageName = getImageName("${value.path}");
                String imageExtension = getImageExtension("${value.path}");
                log("Image Name: $imageName");
                log("Image Extension: $imageExtension");

                socketService!.fileToBuffer(value.path).then((unitFile) {
                  // socketService!.sendImages(
                  //   unitFile,
                  // );
                  String? userId = socketService!.userId;
                  socketService!.sendImages(
                      name: imageName,
                      type: imageExtension,
                      file: unitFile,
                      userId: userId);
                });
              });
            }
          },
          style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30))),
          child: Text(
            "Send",
            style: themeConstant.smallTextSizeDark,
          )),
    );
  }

  String getImageName(String filePath) {
    // Get the file name without the extension
    String fileName = filePath.split('/').last;
    // Remove the extension from the file name
    int extensionIndex = fileName.lastIndexOf('.');
    if (extensionIndex != -1) {
      return fileName.substring(0, extensionIndex);
    }
    return fileName;
  }

  String getImageExtension(String filePath) {
    // Get the file extension
    String fileName = filePath.split('/').last;
    int extensionIndex = fileName.lastIndexOf('.');
    if (extensionIndex != -1) {
      return fileName.substring(extensionIndex + 1);
    }
    return ''; // If there is no extension
  }

  void storingFilesInImageModal() {
    for (int i = 0; i < selectedAssetList.length; i++) {
      selectedAssetList[i].originFile.then((value) {
        log("${value!.path}");
        String imageName = getImageName("${value.path}");
        String imageExtension = getImageExtension("${value.path}");
        log("Image Name: $imageName");
        log("Image Extension: $imageExtension");

        socketService!.fileToBuffer(value.path).then((unitFile) {
          // socketService!.sendImages(
          //   unitFile,
          // );
          String? userId = socketService!.userId;
          listOfImageModal?.add(ImageModal(
              name: imageName,
              type: imageExtension,
              file: unitFile!,
              sender: userId!));
        });
      });
    }

    // if (listOfImageModal != null) {
    //   for (int i = 0; i < listOfImageModal!.length; i++) {
    //     log('$i) Name: ${listOfImageModal![i].name} Extension: ${listOfImageModal![i].type} UserId: ${listOfImageModal![i].senderSocketId}');
    //   }
    // }
    listOfMaps =
        listOfImageModal!.map((imageModal) => imageModal.toMap()).toList();

    for (var map in listOfMaps!) {
      log("$map");
    }
  }

  void sendFilesToServer() {
    //socketService!.sendImages(listOfMaps!);
  }
}
