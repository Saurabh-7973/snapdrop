import 'package:flutter/material.dart';
import 'package:snapdrop/constant/theme_contants.dart';

class HeroText extends StatelessWidget {
  String firstLine;
  String secondLine;
  String thirdLine;

  HeroText(
      {super.key,
      required this.firstLine,
      required this.secondLine,
      required this.thirdLine});

  @override
  Widget build(BuildContext context) {
    final themeConstant = ThemeConstant();

    return Container(
      // color: Colors.amber,
      margin: const EdgeInsets.all(15),
      height: MediaQuery.of(context).size.height / 4,
      width: MediaQuery.of(context).size.width,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          firstLine == '' 
          ? Container()
          : Text(
            firstLine,
            style: themeConstant.largeTextSize,
          ),
          secondLine == '' 
          ? Container()
          : Text(
            secondLine,
            style: themeConstant.largeTextSize,
          ),
          const SizedBox(
            height: 10,
          ),
          thirdLine == '' 
          ? Container()
          : Text(
            thirdLine,
            style: themeConstant.smallTextSizeLight,
          ),
        ],
      ),
    );
  }
}
