import 'dart:developer';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';
import 'package:snapdrop/constant/theme_contants.dart';
import 'package:snapdrop/screen/send_file_screen.dart';
import 'package:snapdrop/services/socket_service.dart';

class QRScanner extends StatefulWidget {
  // const QRScanner({super.key});

  List<AssetEntity> selectedAssetList;

  QRScanner({super.key, required this.selectedAssetList});

  @override
  State<QRScanner> createState() => _QRScannerState();
}

class _QRScannerState extends State<QRScanner> {
  bool scannerVisible = false;
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  Barcode? result;
  QRViewController? _qrViewController;
  List<Uint8List>? bufferList = [];
  String? roomId;
  String? userId;
  bool connectionStatus = false;
  SocketService? socketService;

  @override
  Widget build(BuildContext context) {
    // QRViewController qrViewController;

    var screenHeight = MediaQuery.of(context).size.height;
    var screenWidth = MediaQuery.of(context).size.width;
    ThemeConstant themeConstant = ThemeConstant();

    return Column(
      children: [
        InkWell(
          onTap: () {
            setState(() {
              scannerVisible = scannerVisible == true ? false : true;
            });
          },
          child: Container(
            height: screenHeight / 2.8,
            width: screenWidth / 1.3,
            decoration: BoxDecoration(
                border: Border.all(color: Colors.grey, width: 2),
                borderRadius: BorderRadius.circular(15)),
            child: scannerVisible == false
                ? Center(
                    child: SvgPicture.asset(
                      'assets/svg_asset/camera.svg',
                      color: Colors.white,
                    ),
                  )
                : ClipRRect(
                    borderRadius: BorderRadius.circular(15),
                    child: QRView(
                      key: qrKey,
                      onQRViewCreated: _onQRViewController,
                    ),
                  ),
          ),
        ),
        const SizedBox(
          height: 10,
        ),
        SizedBox(
          width: screenWidth / 1.3,
          height: 40,
          child: ElevatedButton(
              onPressed: () {
                if (result != null) {
                  connectSocket();
                }
              },
              style: ElevatedButton.styleFrom(
                  backgroundColor: result != null ? Colors.green : Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30))),
              child: Text(
                "Connect",
                style: result != null
                    ? themeConstant.smallTextSizeLight
                    : themeConstant.smallTextSizeDark,
              )),
        ),
        // result != null
        // ? Text("${result!.code}",style: themeConstant.smallTextSizeLight ,)
        // : Container(),
        const SizedBox(
          height: 20,
        ),
        Visibility(
          visible: connectionStatus,
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  SizedBox(
                    width: 10,
                    height: 10,
                    child: CircleAvatar(
                      backgroundColor: Colors.green,
                    ),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text(
                    'Connected Successfully',
                    style: TextStyle(color: Colors.white70),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              // if (result != null)
              //   Row(
              //     mainAxisAlignment: MainAxisAlignment.center,
              //     children: [
              //       Text(
              //         socketService!.userId ??
              //             '', // If userId is null, an empty string is used
              //         style: themeConstant.smallTextSizeLight,
              //       )
              //     ],
              //   ),
            ],
          ),
        ),
      ],
    );
  }

  void _onQRViewController(QRViewController qrViewController) {
    _qrViewController = qrViewController;
    qrViewController.scannedDataStream.listen((scanData) {
      setState(() {
        result = scanData;
      });
      qrViewController.pauseCamera();
    });
  }

  connectSocket() async {
    '${result!.code}'.toString().split('=')[1];

    socketService = SocketService(url: '${result!.code}');
    socketService!.connectToSocketServer();

    setState(() {
      socketService != null
          ? connectionStatus = true
          : connectionStatus = false;
    });

    Future.delayed(const Duration(seconds: 2), () {
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => SendFile(
                    selectedAssetList: widget.selectedAssetList,
                    roomId: '${result!.code}'.toString().split('=')[1],
                    socketService: socketService,
                  )));
    });

    // await listDownAsset(widget.selectedAssetList);

    //     IO.Socket socket = IO.io('https://getsnapdrop.in/',
    //     OptionBuilder()
    //         .setTransports(['websocket']) // for Flutter or Dart VM
    //         .setTimeout(10000)
    //         //.setExtraHeaders({'foo': 'bar'}) // optional
    //         .build());

    //     socket.connect();

    //     socket.emit('test','sad');

    //     socket.onConnect((data) {
    //       log('Socket Connected $data');
    //     });

    //     socket.on('connect_error', (error) {
    //       print('Connection Error: $error');
    //     });

    //     log('${result!.code}');
    //     roomId = result!.code.toString().split('=')[1];
    //     log("Room Id: $roomId");

    //     socket.on('your_id', (data) {
    //       log('Your ID: ${data['id']}');
    //       userId = data['id'];

    //       socket.emit("join_figma_room", {
    //       'my_id': userId,
    //       'room': roomId,
    //       });

    //       socket.emit("image", {
    //       'room': roomId,
    //       'files':  [{
    //           'name': 'test',
    //           'type': 'png',
    //           'file': '${bufferList![0]}',
    //           'sender': userId,
    //             }],
    //       });
    //     });

    // socket.emit('join', [roomName]);
  }

  listDownAsset(List<AssetEntity> selectedAssetList) async {
    for (int i = 0; i < selectedAssetList.length; i++) {
      selectedAssetList[i].originBytes.then((value) async {
        bufferList!.add(value!);
        log(bufferList![i].toString());
      });
    }
  }
}
