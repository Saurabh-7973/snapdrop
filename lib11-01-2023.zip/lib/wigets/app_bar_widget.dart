import 'package:flutter/material.dart';

class AppBarWidget extends StatelessWidget {
  const AppBarWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: const Color.fromARGB(20, 37, 37, 37),
          borderRadius: BorderRadius.circular(30),
          border: Border.all(
            color: Colors.white,
            width: 2,
          )),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
        child: Row(
          children: const [
            // Image.asset("assets/history.png"),
            Icon(
              Icons.history,
              color: Colors.white,
            ),
            Spacer(),
            // Image.asset("assets/snapdrop_logo.png"),
            Text(
              "Snapdrop",
              style: TextStyle(
                  fontStyle: FontStyle.italic,
                  color: Colors.white,
                  fontSize: 20),
            ),
            Spacer(),
            // Image.asset("assets/vertical_menu.png"),
            Icon(
              Icons.more_vert,
              color: Colors.white,
            ),
          ],
        ),
      ),
    );
  }
}
