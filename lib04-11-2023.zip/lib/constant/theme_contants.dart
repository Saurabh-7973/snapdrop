import 'package:flutter/material.dart';

class ThemeConstant{
  Color whiteColor = const Color(0xffFFFFFF);
  Color greenAccentColor = const Color(0xff39C679);
  var largeTextSize = const TextStyle(fontSize: 36,color: Colors.white,fontWeight: FontWeight.w600);
  var smallTextSizeLight = const TextStyle(fontSize: 16,color: Colors.white);
  var smallTextSizeDark = const TextStyle(fontSize: 16,color: Colors.black);
}