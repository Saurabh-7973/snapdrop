import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';
import 'package:snapdrop/screen/home_screen.dart';

import 'screen/intent_sharing_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this); // Add the observer
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    // TODO: implement dispose
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // TODO: implement didChangeAppLifecycleState
    log('State : $state');

    if (state == AppLifecycleState.paused) {
      log('App Paused Triggered');
    }
    if (state == AppLifecycleState.resumed) {
      log('App Resumed Triggered');
      ReceiveSharingIntent.getMediaStream().listen(
          (List<SharedMediaFile> listOfMedia) async {
        if (listOfMedia.isNotEmpty) {
          Navigator.pop(context);
          await Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => IntentSharingScreen(
                        listOfMedia: listOfMedia,
                      )));
        }
      }, onError: (err) {
        debugPrint("Error : $err");
      });
    }

    //super.didChangeAppLifecycleState(state);
  }

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
  return MaterialApp(
    home: FutureBuilder<List<SharedMediaFile>>(
      future: ReceiveSharingIntent.getInitialMedia(),
      builder: (BuildContext context, AsyncSnapshot<List<SharedMediaFile>> snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          if (snapshot.hasData && snapshot.data!.isNotEmpty) {
            return IntentSharingScreen(listOfMedia: snapshot.data);
          } else {
            return HomeScreen();
          }
        } else {
          // You can return a loading indicator or an empty container here
          return CircularProgressIndicator(); // Replace with your loading UI
        }
      },
    ),
  );
}
}
