import 'dart:io';

import 'package:flutter/material.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';
import 'package:snapdrop/constant/theme_contants.dart';

import '../screen/qr_screen.dart';
import '../services/socket_service.dart';

class IntentFileDisplayer extends StatelessWidget {
   
  List<AssetEntity>? selectedAssetList;
  SocketService? socketService;
  bool isIntentSharing = false;
  List<SharedMediaFile>? listOfMedia;
  bool connectDisplayer = false;
   
   IntentFileDisplayer({super.key , required this.isIntentSharing , this.listOfMedia , this.socketService , this.selectedAssetList , required this.connectDisplayer});


  @override
  Widget build(BuildContext context) {

    var screenHeight = MediaQuery.of(context).size.height;
    var screenWidth = MediaQuery.of(context).size.width;
    ThemeConstant themeConstant = ThemeConstant();
    
    return Expanded(
                  child: Stack(
                    children: [
                      Expanded(
                        child: GridView.builder(
                            itemCount: listOfMedia!.length,
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 3,
                                    crossAxisSpacing: 6,
                                    mainAxisSpacing: 6,
                                    childAspectRatio: (2 / 3)),
                            itemBuilder: (context, index) {
                              return Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(5),
                                ),
                                child: ClipRRect(
                                    borderRadius: BorderRadius.circular(5),
                                    child: Image.file(
                                      File(listOfMedia![index].path),
                                      fit: BoxFit.cover,
                                    )),
                              );
                            }),
                      ),
                      Visibility(
                        visible: connectDisplayer,
                        child: Align(
                          alignment: Alignment.bottomRight,
                          child: Container(
                            width: screenWidth / 3.6,
                            height: 40,
                            margin: const EdgeInsets.symmetric(
                                vertical: 8, horizontal: 8),
                            child: ElevatedButton(
                              onPressed: () {
                                Navigator.push(context, MaterialPageRoute(builder: (context) => QRScreen(isIntentSharing: true,listOfMedia: listOfMedia,) ));
                              },
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.white,
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(30))),
                              child: Row(
                                children: [
                                  Text(
                                    "Connect",
                                    style: themeConstant.smallTextSizeDark,
                                  ),
                                  const Spacer(),
                                  const Icon(
                                    Icons.arrow_forward_rounded,
                                    color: Colors.black,
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                );
  }
}