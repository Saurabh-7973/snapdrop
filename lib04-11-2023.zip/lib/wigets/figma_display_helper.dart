import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:snapdrop/constant/theme_contants.dart';

class FigmaDisplayHelper extends StatelessWidget {
  const FigmaDisplayHelper({super.key});

  @override
  Widget build(BuildContext context) {
    ThemeConstant themeConstant = ThemeConstant();
    var screenHeight = MediaQuery.of(context).size.height;
    var screenWidth = MediaQuery.of(context).size.width;

    return SizedBox(
      width: screenWidth / 2,
      child: Center(
        child: Row(
          children: [
            SvgPicture.asset('assets/svg_asset/figma.svg'),
            const Spacer(),
            Text(
              "Scan QR code to Connect",
              style: themeConstant.smallTextSizeLight,
            )
          ],
        ),
      ),
    );
  }
}
